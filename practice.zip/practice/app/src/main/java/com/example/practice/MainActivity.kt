package com.example.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.content.Intent
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var Next = findViewById<Button>(R.id.button)
        Next.setOnClickListener{
            val intent = Intent(this, Main2::class.java)
            startActivity(intent)
        }
    }
}